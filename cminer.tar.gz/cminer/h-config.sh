#!/usr/bin/env bash

function miner_ver() {
  local MINER_VER=$CMINER_VER
  [[ -z $MINER_VER ]] && MINER_VER=$MINER_LATEST_VER
  echo $MINER_VER
}

function miner_config_echo() {
  local MINER_VER=`miner_ver`
  miner_echo_config_file "$MINER_DIR/$MINER_VER/miner.conf"
}

function miner_config_gen() {
  local conf=
  local MINER_CONFIG="$MINER_DIR/dynex.conf"

  [[ $CMINER_URL =~ (.*):([0-9]+) ]] && CMINER_SERVER=${BASH_REMATCH[1]} && CMINER_PORT=${BASH_REMATCH[2]}

  conf="export MAX_GPU=16"$'\n'
  conf+="WAL=\"$CMINER_TEMPLATE\""$'\n'
  conf+="HOST=\"$CMINER_SERVER\""$'\n'
  conf+="PORT=\"$CMINER_PORT\""$'\n'
  conf+="PASS=\"$CMINER_PASS\""$'\n'
  conf+="EXTRA=\"$CMINER_USER_CONFIG\""$'\n'

  echo "$conf" > $MINER_CONFIG

}
