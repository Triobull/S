#!/usr/bin/env bash

cd $MINER_DIR

source dynex.conf

dynex -skip -stats stats.json -sync -mining-address $WAL -no-cpu -stratum-url $HOST -stratum-port $PORT ${PASS:+-stratum-password} $PASS $EXTRA 2>&1 | tee --append $MINER_LOG_BASENAME.log

