#!/usr/bin/env bash

	#CUSTOM_DIR=$(dirname "$BASH_SOURCE")

	#source /hive/miners/dstm/h-manifest.conf
	#source /hive/miners/dstm/0.6.2/zm.conf
	#LOG=/var/log/miner/dstm/dstm.log
	#STATS=/hive/miners/dstm/0.6.2/stats.json
	STATS=/hive/miners/ewbf/stats.json

	algo="cryptonight"

	khs=0
	stats=0
	uptime=0
	ac=0
	rj=0

	hash_arr="null"
	bus_numbers="null"

	now=$(date +%s)
	upd=$(stat -c %Y $STATS 2>/dev/null)
	if (( $? == 0 && upd + 180 > now )); then
		readarray -t arr < <(jq -rc '.ver, .avg, .hr, .ac, .rj, .uptime, .gpu, .bus_numbers' $STATS)
		ver=${arr[0]}
		avg=${arr[1]}
		hs=${arr[2]}
		ac=${arr[3]}
		rj=${arr[4]}
		uptime=${arr[5]}
		hash_arr="${arr[6]}"
		bus_numbers="${arr[7]}"
		khs=$( echo "$avg" | awk '{ printf $1/1000}')
	else
		echo "No stats.json"
	fi

	stats=$(jq -n --arg ac "$ac" --arg rj "$rj" --arg algo "$algo" --argjson bus_numbers "$bus_numbers" --argjson hs "$hash_arr" --arg uptime "$uptime" --arg ver "$ver" \
		'{hs_units: "hs", $hs, $algo, $ver, $uptime, $bus_numbers, ar:[$ac|tonumber,$rj|tonumber]}')


	#echo $khs
	#echo $stats
